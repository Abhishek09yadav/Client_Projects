import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import './Category.css';
import Item from '../item/item';
import html2pdf from 'html2pdf.js';
import { Link } from "react-router-dom";
import logo from "../Assets/logo.png";
import { ShopContext } from '../../Context/ShopContext'; // Import the context
import signanureimg from "../Assets/signature.jpeg";
const Category = () => {
    const [totalQuantity, setTotalQuantity] = useState(0);

    const [categories, setCategories] = useState([]);
    const [allProducts, setAllProducts] = useState([]); // Store all products across categories
    const [products, setProducts] = useState([]); // Products for current category
    const [selectedCategory, setSelectedCategory] = useState("");
    const [selectedProducts, setSelectedProducts] = useState({});
    const [totalPrice, setTotalPrice] = useState(0);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedItems, setSelectedItems] = useState([]);
    const { userDetails } = useContext(ShopContext);
    const handleOnClick = () => {
        const element = document.querySelector('#generate-pdf');
        console.log("PDF button clicked");
        html2pdf(element);
    };

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const response = await axios.get('http://localhost:4000/categories');
                setCategories(response.data);
                const productsResponse = await axios.get('http://localhost:4000/allproducts');
                setAllProducts(productsResponse.data);
            } catch (error) {
                console.error("Error fetching categories or products:", error);
            }
        };
        fetchCategories();
    }, []);

    const fetchProductsByCategory = (category) => {
        setSelectedCategory(category);
        const categoryProducts = allProducts.filter(product => product.category === category);
        setProducts(categoryProducts);
    };

    const handleProductSelection = (productId, isChecked) => {
        setSelectedProducts((prevSelectedProducts) => {
            const newSelectedProducts = { ...prevSelectedProducts };
            if (isChecked) {
                newSelectedProducts[productId] = { quantity: 1 };
                setTotalQuantity((prevTotal) => prevTotal + 1); // Add 1 to total
            } else {
                setTotalQuantity((prevTotal) => prevTotal - newSelectedProducts[productId].quantity); // Subtract product quantity from total
                delete newSelectedProducts[productId];
            }
            return newSelectedProducts;
        });
    };


    const handleQuantityChange = (productId, quantity) => {
        const parsedQuantity = parseInt(quantity, 10) || 0;
        setSelectedProducts((prevSelectedProducts) => {
            const newSelectedProducts = { ...prevSelectedProducts };
            if (newSelectedProducts[productId]) {
                const previousQuantity = newSelectedProducts[productId].quantity;
                newSelectedProducts[productId].quantity = parsedQuantity;
                setTotalQuantity((prevTotal) => prevTotal + (parsedQuantity - previousQuantity)); // Adjust total
            }
            return newSelectedProducts;
        });
    };


    const generateQuery = () => {
        let total = 0;
        const selectedItems = Object.keys(selectedProducts).map((productId) => {
            const product = allProducts.find(item =>
                item.id === Number(productId) || item._id === productId
            );
            if (!product) {
                console.error(`Product with ID ${productId} not found.`);
                return null;
            }
            const quantity = parseInt(selectedProducts[productId].quantity, 10);
            const price = product.new_price;
            const itemTotal = price * quantity;
            total += itemTotal;
            return {
                name: product.name,
                quantity,
                totalPrice: itemTotal,
                category: product.category
            };
        }).filter(item => item !== null);

        setTotalPrice(total);
        setSelectedItems(selectedItems);
        setIsModalOpen(true);
    };
    console.log("user details ", userDetails)
    return (
        <div className={'Category'}>
            <h1>Categories</h1>
            <hr />
            <div className="category-container">
                {categories.map((category, index) => (
                    <div
                        key={index}
                        className={`category-pill ${selectedCategory === category ? "active" : ""}`}
                        onClick={() => fetchProductsByCategory(category)}
                    >
                        {category}
                    </div>
                ))}
            </div>
            {selectedCategory && (
                <div>
                    <h3>Products in {selectedCategory}</h3>
                    {products.length > 0 ? (
                        <div className="products-grid">
                            {products.map((item) => (
                                <div key={item.id} className="product-item">
                                    <Item
                                        id={item.id}
                                        name={item.name}
                                        image={item.image}
                                        new_price={item.new_price}
                                        old_price={item.old_price}
                                    />
                                    <input
                                        type="checkbox"
                                        checked={!!selectedProducts[item.id]}
                                        onChange={(e) => handleProductSelection(item.id, e.target.checked)}
                                    />
                                    {selectedProducts[item.id] && (
                                        <div className={'Quantity-field'}>
                                            <p>Quantity: </p>
                                            <input
                                                type="number"
                                                min="1"
                                                value={selectedProducts[item.id].quantity}
                                                onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                                            />
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p>No products found for this category.</p>
                    )}
                </div>
            )}
            <button className="query-generator-button" onClick={generateQuery}>
                Query Generator
            </button>
            {totalPrice > 0 && (
                <div className="total-price">
                    <p>Total Price: ₹{totalPrice.toFixed(2)}</p>
                </div>
            )}
            {isModalOpen && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <h3>Selected Products</h3>
                        <div id={"generate-pdf"}>
                            <Link to={'/'} className="nav-logo" style={{textDecoration: 'none'}}>
                                <img src={logo} alt="logo"/>
                                <p>NAVKAR</p>
                            </Link>
                            <div className="details">
                                <div className="company-details-box">
                                    <p className={"company-details"}>Contact: 1234</p>
                                    <p className={"company-details"}>mail: 1234@nav.com</p>
                                    <p className={"company-details"}>Address: 1234</p>
                                </div>
                                <div className="customer-details-box">
                                    <div>
                                        {userDetails ? (
                                            <div>
                                                <p className={"customer-details"}>Welcome, {userDetails.name}!</p>
                                                <p className={"customer-details"}>Email: {userDetails.email}</p>
                                            </div>
                                        ) : (
                                            <p>Loading user details...</p>
                                        )}
                                    </div>
                                </div>
                            </div>
                            <table className="selected-products-table">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Quantity</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Tax</th>
                                    <th>Total Price</th>
                                </tr>
                                </thead>
                                <tbody>
                                {selectedItems.map((item, index) => (
                                    <tr key={index}>
                                        <td>{item.name}</td>
                                        <td>{item.quantity}</td>
                                        <td>{item.category}</td>

                                        <td>₹{item.totalPrice.toFixed(2)}</td>
                                        <td>28%</td>
                                        <td>₹{item.totalPrice.toFixed(2)}</td>
                                    </tr>
                                ))}
                                </tbody>
                            </table>
                            <div className="total-price">
                                <p><strong>Final Total: ₹{totalPrice.toFixed(2)}</strong></p>
                            </div>
                            {totalQuantity > 0 && (
                                <div className="total-quantity">
                                    <p>Total Quantity: {totalQuantity}</p>
                                </div>
                            )}

                            <h3>Sign: <img src={signanureimg} className={'signature'}/></h3>
                        </div>
{/*pdf generation ends here*/}
                        <button onClick={handleOnClick}>PDF</button>
                        <button onClick={() => setIsModalOpen(false)}>Close</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Category;
