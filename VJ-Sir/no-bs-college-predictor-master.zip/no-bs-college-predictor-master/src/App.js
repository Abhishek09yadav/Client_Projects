import React from 'react'

import './App.css'
import CollegePredictor from './components/CollegePredictor/CollegePredictor'

const App = () => (
  <div className="app">
    <CollegePredictor />
  </div>
)

export default App
