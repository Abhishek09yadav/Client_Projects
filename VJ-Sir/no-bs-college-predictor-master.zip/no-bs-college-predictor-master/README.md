# No Bullshit College Predictor

Every year lakhs of Indian students give JEE and then while filling JoSAA they try to fetch an easy interface to be able to list project they can easily get in their Rank.
This process is used as data-aggerating and never-ending spam sites all over the web.

We have personally faced this issue when we are looking for colleges as well as when looking for some sibling in family.

This project aims to provide you to the point info, no login, no data taken, no bullshit.
